GLOBAL SHOPPING MART - STARTER PROJECT
Open index.html in a browser to use the prototype.

Demo features:
- Country/currency display (illustrative exchange multipliers, not live FX)
- Product catalogue, search, category filter, cart
- Admin demo markup control
- Add demo products and import/export CSV

NOT LIVE/PRODUCTION:
- Supplier API imports and order fulfilment are not connected.
- Payment processing is not connected.
- Currency rates are illustrative, not live.
- No secure admin authentication or persistent database.
- Before launching publicly: use a hosted commerce platform or backend; configure supplier integration; shipping, taxes, payments, privacy, security and business/legal requirements.

On Android: download ZIP, extract using Files app, open index.html with browser. Hosting is needed for a public URL.
